#!/bin/bash
set -x
export DEPTS="67 68 54 55 57 88 25 70 90"

should_reset_volume()
{
 ret=0

 if [ ! -f "/data/.initialized"  ]
 then
   ret=1
   return $ret
 fi
 ADEPTS=($DEPTS)
 IFS=$'\n' SDEPTS=($(sort <<<"${ADEPTS[*]}"))
 unset IFS
 COUNT_REQUIRED_CORES=$[ 2* ${#ADEPTS[*]} ]
 RETRIEVED_CORES=$(find /data -mindepth 1 -maxdepth 1 -type d)
 COUNT_RETRIEVED_CORES=$(wc -l <<<${RETRIEVED_CORES} )
 RETRIEVED_DEPTS=$((cut -d '_' -f 2 <<< ${RETRIEVED_CORES})|sort -u)
 ARETRIEVED_DEPTS=(${RETRIEVED_DEPTS})
 if [  ${COUNT_REQUIRED_CORES} -ne ${COUNT_RETRIEVED_CORES} ]
 then
   ret=1
   return $ret
 fi

 if [ "${ARETRIEVED_DEPTS[*]}" != "${SDEPTS[*]}" ]
 then
  ret=1
  return $ret
 fi

 for i in ${DEPTS}
 do
  for j in active passive
  do
    diff -s --recursive --exclude='data' --exclude='core.properties' --exclude='.*' /opt/solr/server/solr/configsets/civiaddr /data/core_${i}_${j}
    if [ $? -ne 0 ]
    then
     ret=1
     return $ret
    fi
  done
 done

return $ret
}
do_reset_volume()
{
  rm -Rf /data/core_*
}


precreate_core()
{
for DEPT in ${DEPTS}
do
  for core in core_${DEPT}_active core_${DEPT}_passive
  do
    if [[ -d /var/solr/data/${core} ]]
    then
      echo "${core} already exists"
    else
      echo "creating ${core}"
      precreate-core "${core}" /opt/solr/server/solr/configsets/civiaddr
    fi
  done
done
}

create_core()
{
for DEPT in ${DEPTS}
do 
  for core in core_${DEPT}_active core_${DEPT}_passive
  do
    solr create  -c "${core}" -d civiaddr -s "${SOLR_DEST}"
  done
done
}

coreIndex()
{
if [[ -z "${SOLR_DEST}" ]]
then
   echo "SOLR_DEST not set"
   exit 1;
fi

for DEPT in ${DEPTS}
do
  echo "delete all documents from core_${DEPT}_passive"
  echo "<delete><query>id:*</query></delete>"| solr post -s "${SOLR_DEST}" --mode stdin -t text/xml -c "core_${DEPT}_passive" --verbose
  DESTFILE=/tmp/adresses-${DEPT}.csv.gz
  CONTENTFILE=/tmp/adresses-${DEPT}.tmp
  DATAFILE=/tmp/adresses-${DEPT}.csv
  echo "Downloading addr file for ${DEPT}"

  wget --no-verbose --save-headers -O "${DESTFILE}" "https://adresse.data.gouv.fr/data/ban/adresses/latest/csv/adresses-${DEPT}.csv.gz"
#  wget --no-verbose --save-headers -O "${DESTFILE}" "http://httpaddr.httpaddr/adresses-${DEPT}.csv.gz"
  echo "Preparing data file for ${DEPT}"
  modified=$(sed -u '/^\r$/q' "${DESTFILE}"|grep "Last-Modified"|cut -f 2- -d ':'|xargs)
  (cat "${DESTFILE}"|(sed -u -n '/^\r$/q' ; zcat -)) >"${CONTENTFILE}"

  sed -E -e "1s/^(.*)\$/\\1;numero_rep;numero_departement;modified/" -e "2,\$s/(^([^;]*;){2})([^;]*);([^;]*);(.*)\$/\\1\\3;\\4;\\5;\\3\\4;${DEPT};${modified}/" "${CONTENTFILE}" >"${DATAFILE}"
  echo "Indexing data file for ${DEPT}"
#  solr post --mode files -ft csv -p separator=\; -url "${SOLR_DEST}/solr/core_${DEPT}_passive/update" --out "${DATAFILE}" #fonctionne en init
  solr post -s "${SOLR_DEST}" --mode files -ft csv --params separator=\;  -c "core_${DEPT}_passive" --verbose "${DATAFILE}"
  echo "swap cores for ${DEPT}"
  solr api --solr-url "${SOLR_DEST}/admin/cores?action=SWAP&core=core_${DEPT}_active&other=core_${DEPT}_passive"
done

}

local_init_core()
{
 should_reset_volume
 if [ $? -eq 0 ]
 then
   exit 0
 else
   do_reset_volume
   export SOLR_DEST="https://localhost:8983/"
   solr start --user-managed
   create_core
   coreIndex
   solr stop
   touch /data/.initialized
 fi
}

remote_index_core()
{
  export SOLR_DEST="https://civisolr:443/"
  coreIndex
}

# Uncomment if you want to override previously defined SSL values for HTTP client
# otherwise keep them commented and the above values will automatically be set for HTTP clients
#SOLR_SSL_CLIENT_KEY_STORE=
#SOLR_SSL_CLIENT_KEY_STORE_PASSWORD=
#SOLR_SSL_CLIENT_TRUST_STORE=
#SOLR_SSL_CLIENT_TRUST_STORE_PASSWORD=
#SOLR_SSL_CLIENT_KEY_STORE_TYPE=
#SOLR_SSL_CLIENT_TRUST_STORE_TYPE=
